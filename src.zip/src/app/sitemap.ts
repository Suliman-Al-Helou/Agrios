import { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    { url: "https://agrios.com",       lastModified: new Date(), priority: 1 },
    { url: "https://agrios.com/about", lastModified: new Date(), priority: 0.8 },
  ];
}