"use client";
import { ServicesSectionData } from "@/types/Service";

interface ServicesSectionProps {
  data: ServicesSectionData["services"]; // هذا array من الخدمات
}
import Link from "next/link";
import Image from "next/image";
import { motion } from "motion/react";
import { cardAnimation, staggerContainer } from "@/lib/animations";

export default function ServicesSection({ data }: ServicesSectionProps) {
  return (
    <section className="py-16 bg-white">
      <div className="mx-auto max-w-6xl px-4">
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {data.map((service) => (
            <motion.div
              key={service.id}
              variants={cardAnimation}
              className="relative rounded-xl shadow-lg overflow-hidden cursor-pointer hover:scale-105 transition-transform duration-300 bg-white"
            >
              <div className="relative h-64 w-full">
                <Link href={service.href}>
                  <Image src={service.image} alt={service.imageAlt} fill className="object-cover" />
                  <div>{service.title}</div>
                </Link>
              </div>
              <div className="absolute top-0 left-0 w-full text-center bg-white py-2 font-semibold">
                {service.title}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}